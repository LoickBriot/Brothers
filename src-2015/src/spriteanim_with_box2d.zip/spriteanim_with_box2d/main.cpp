// Sylvain.Lefebvre@inria.fr  2015-03-10

//x pour commencer
//o pour simuler la fin
//r pour redemarrer
// ------------------------------------------------------------------

#include "common.h"
#include "drawimage.h"

LIBSL_WIN32_FIX;

// ------------------------------------------------------------------

#include "tilemap.h"
#include "entity.h"
#include "background.h"
#include "physics.h"
#include "sound.h"


// ------------------------------------------------------------------

// Constants

int    c_ScreenW = 650;
int    c_ScreenH = 650;
int    separation = 150;
int    ratio_split = 2;

// ------------------------------------------------------------------

time_t          g_LastFrame    = 0;
bool            g_Keys[256];

Tilemap        *g_Tilemap = NULL;
Background     *g_Bkg1 = NULL;
Background     *g_Bkg2 = NULL;
Background     *g_HomeBkg = NULL;
Background     *g_EndBkg = NULL;

enum state { waiting_to_start, playing, waiting_to_restart } g_State;

vector<Entity*> g_Entities;
Entity*         g_Player1       = NULL;
Entity*         g_Player2       = NULL;

v2i 			g_viewpos1 = NULL;
v2i 			g_viewpos2 = NULL;

int             numFootContacts1 = 0;
int             numLeftContacts1 = 0;
int             numRightContacts1 = 0;
int             numFootContacts2 = 0;
int             numLeftContacts2 = 0;
int             numRightContacts2 = 0;

// ------------------------------------------------------------------

// 'mainKeyPressed' is called everytime a key is pressed
void mainKeyPressed(uchar key)
{
  g_Keys[key] = true;

  if (key == ' ') {
	  Entity *c = entity_create("coin0", "coin.lua");
	  entity_set_pos(c, v2f(256 + ((rand() % 128) - 64), 350));
	  g_Entities.push_back(c);
  }

  if (key == 'j' && (numFootContacts1 > 0 || numLeftContacts1 > 0  || numRightContacts1 > 0)) {
	play_sound("saut.wav");
  }


  if (key == 'p' && (numFootContacts2 > 0 || numLeftContacts2 > 0 || numRightContacts2 > 0)) {
	  play_sound("saut.wav");
  }
  
}

// ------------------------------------------------------------------

// 'mainKeyUnpressed' is called everytime a key is released
void mainKeyUnpressed(uchar key)
{
  g_Keys[key] = false;
}

// ------------------------------------------------------------------

// 'mainRender' is called everytime the screen is drawn
void mainRender()
{
  //// Compute elapsed time
  time_t now = milliseconds();
  time_t el = now - g_LastFrame;
  if (el > 50) {
    g_LastFrame = now;
  }

  //// Physics
  phy_step();
  
  //// Logic


  // -> step all entities
  for (int a = 0; a < (int)g_Entities.size(); a++) {
    entity_step(g_Entities[a],el);
  }

  g_viewpos1[0] = (int)entity_get_pos(g_Player1)[0] - c_ScreenW / 2;
  g_viewpos1[1] = (int)entity_get_pos(g_Player1)[1] - c_ScreenH / 2;
  g_viewpos2[0] = (int)entity_get_pos(g_Player2)[0] - c_ScreenW / 2;
  g_viewpos2[1] = (int)entity_get_pos(g_Player2)[1] - c_ScreenH / 2;

  // -> update viewpos (x coord only in this 'game')
 
  g_Bkg1->viewpos[0] = (int)entity_get_pos(g_Player1)[0];
  g_Bkg1->viewpos[1] = (int)entity_get_pos(g_Player1)[1];
  g_Bkg2->viewpos[0] = (int)entity_get_pos(g_Player2)[0];
  g_Bkg2->viewpos[1] = (int)entity_get_pos(g_Player2)[1];


  //// Display

  clearScreen();
  // -> draw background
  background_draw(g_Bkg1, g_viewpos1);
  background_draw(g_Bkg2, g_viewpos2);
  // -> draw tilemap
  tilemap_draw(g_Tilemap, g_viewpos1, 0);
  tilemap_draw(g_Tilemap, g_viewpos2, c_ScreenW + separation);

  // -> draw all entities
  for (int a = 0; a < (int)g_Entities.size(); a++) {
	  entity_draw(g_Entities[a], g_viewpos1,0);
	  entity_draw(g_Entities[a], g_viewpos2, c_ScreenW + separation);
  }
  // -> draw physics debug layer
  //phy_debug_draw();
}

// ------------------------------------------------------------------




// 'main' is the starting point of the application
int main(int argc,const char **argv)
{
  try { // error handling

    // opens a window
	SimpleUI::init(c_ScreenW*ratio_split + separation, c_ScreenH, "Tilemap");
    // set the render function to be 'mainRender' defined above
    SimpleUI::onRender       = mainRender;
    // set the keyboard function
    SimpleUI::onKeyPressed   = mainKeyPressed;
    SimpleUI::onKeyUnpressed = mainKeyUnpressed;

    // init drawimage library
	drawimage_init(c_ScreenW*ratio_split + separation, c_ScreenH);

    // keys
    for (int i = 0; i < 256; i++) {
      g_Keys[i] = false;
    }

    ///// Level creation

    // create background
    g_Bkg1 = background_init(c_ScreenW, c_ScreenH);
	g_Bkg2 = background_init(c_ScreenW, c_ScreenH);
    // load a tilemap
    g_Tilemap = tilemap_load("level.lua");

    // init physics
    phy_init();

    // bind tilemap to physics
    tilemap_bind_to_physics(g_Tilemap);

    // load a simple entity
    /*{
      Entity *c = entity_create("coin0", "coin.lua");
      entity_set_pos(c, v2f(32, 32));
      g_Entities.push_back(c);
    }  {
      Entity *c = entity_create("coin1", "coin.lua");
      entity_set_pos(c, v2f(96, 32));
      g_Entities.push_back(c);
    } {
      Entity *c = entity_create("coin2", "coin.lua");
      entity_set_pos(c, v2f(128, 32));
      g_Entities.push_back(c);
    }*/ {
      Entity *c = entity_create("player1", "player1.lua");
      entity_set_pos(c, v2f(996,964));
      g_Player1 = c;
      g_Entities.push_back(c);

	  
	} {
		Entity *c = entity_create("player2", "player2.lua");
		entity_set_pos(c, v2f(1000, 800));
		g_Player2 = c;
		g_Entities.push_back(c);
	}

    g_LastFrame = milliseconds();


	init_sound();
    // enter the main loop
    SimpleUI::loop();
    
    // terminate physics
    phy_terminate();
    // terminate drawimage
    drawimage_terminate();

    // close the window
    SimpleUI::shutdown();

  } catch (Fatal& f) { // error handling
    std::cerr << Console::red << f.message() << Console::gray << std::endl;
  }

  return 0;
}

// ------------------------------------------------------------------
